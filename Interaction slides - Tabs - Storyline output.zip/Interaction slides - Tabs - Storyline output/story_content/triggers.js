function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6VA2ebJAr1J":
        Script1();
        break;
      case "5Y71QnODleZ":
        Script2();
        break;
      case "6cjLFfEZeBp":
        Script3();
        break;
      case "5mJptwUMyNZ":
        Script4();
        break;
      case "638vvR5iALY":
        Script5();
        break;
      case "6GoLio1Gmre":
        Script6();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
};
